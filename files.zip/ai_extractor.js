/**
 * services/ai_extractor.js
 * 
 * AI-powered business data extraction & normalization
 * Uses open-source LLMs (Mistral, LLaMA, etc) via Hugging Face or Ollama
 * 
 * Cost: ~$0.0001-0.001 per extraction (vs $0.01-0.02 with Claude)
 */

'use strict';

const axios = require('axios');

// ─── CONFIGURATION ──────────────────────────────────────────────────────────
const HF_API_KEY = process.env.HF_API_KEY;  // Hugging Face API key
const LLM_MODEL = 'mistralai/Mistral-7B-Instruct-v0.1';  // Fast, efficient model
const HF_INFERENCE_URL = `https://api-inference.huggingface.co/models/${LLM_MODEL}`;

// For local Ollama: const OLLAMA_URL = 'http://localhost:11434/api/generate';

const CATEGORY_MAPPING = {
  electronics: ['phone', 'computer', 'laptop', 'appliance', 'tv', 'electronics', 'gadget', 'device'],
  'legal services': ['lawyer', 'law firm', 'attorney', 'counsel', 'solicitor', 'barrister'],
  'health & medical': ['hospital', 'clinic', 'doctor', 'pharmacy', 'medical', 'health'],
  'retail & trading': ['shop', 'store', 'market', 'trading', 'retail', 'vendor', 'merchant'],
  'auto & transport': ['garage', 'mechanic', 'car', 'transport', 'taxi', 'vehicle', 'auto'],
  'food & beverage': ['restaurant', 'cafe', 'bar', 'food', 'bakery', 'hotel', 'catering'],
  'agriculture & farming': ['farm', 'agriculture', 'agro', 'crop', 'livestock', 'poultry'],
  'education': ['school', 'college', 'university', 'training', 'tuition', 'institute'],
  'construction': ['builder', 'construction', 'contractor', 'cement', 'building', 'real estate'],
  'services': ['service', 'consultant', 'consultant', 'agency', 'studio'],
};

// ─── MAIN EXTRACTION FUNCTION ──────────────────────────────────────────────
/**
 * Extract & normalize business data from raw source
 * 
 * @param {Object} rawData - Raw business data from Google Maps, OSM, web crawl, etc
 * @param {String} source - Data source ('google_maps', 'openstreetmap', 'web_crawl')
 * @returns {Promise<Object>} - Extracted & normalized business data with confidence score
 */
async function extractBusinessData(rawData, source = 'unknown') {
  try {
    // ─ Step 1: Create extraction prompt
    const prompt = createExtractionPrompt(rawData, source);

    // ─ Step 2: Call LLM for extraction
    const extracted = await callLLM(prompt);

    // ─ Step 3: Parse & normalize
    const normalized = normalizeExtraction(extracted, rawData);

    // ─ Step 4: Auto-categorize
    normalized.category = autoDetectCategory(normalized);

    // ─ Step 5: Calculate confidence score
    normalized.confidence_score = calculateConfidence(normalized, source, rawData);
    normalized.confidence_breakdown = getConfidenceBreakdown(normalized, source);

    return {
      success: true,
      extracted: normalized,
      raw_input: rawData,
      source,
      extracted_at: new Date().toISOString(),
    };
  } catch (err) {
    console.error('[AI Extractor Error]', err.message);
    return {
      success: false,
      error: err.message,
      raw_input: rawData,
      source,
    };
  }
}

// ─── EXTRACTION PROMPT ──────────────────────────────────────────────────────
function createExtractionPrompt(rawData, source) {
  const dataStr = JSON.stringify(rawData, null, 2);

  return `You are a data extraction specialist. Extract business information from the following data and return ONLY valid JSON.

Source: ${source}
Raw data:
${dataStr}

Extract and return ONLY this JSON structure (no markdown, no extra text):
{
  "business_name": "extracted business name",
  "phone_number": "normalized phone number (include country code like +234)",
  "address": "full address",
  "city": "city name",
  "state": "state/province",
  "country": "Nigeria|Ghana|Kenya",
  "website": "website URL or null",
  "operating_hours": "hours of operation or null",
  "description": "brief business description",
  "keywords": ["keyword1", "keyword2"],
  "data_quality": {
    "has_phone": true|false,
    "has_address": true|false,
    "has_website": true|false,
    "completeness": 0.0-1.0
  }
}`;
}

// ─── CALL LLM (Hugging Face or local Ollama) ────────────────────────────────
async function callLLM(prompt) {
  try {
    // Option 1: Hugging Face (requires HF_API_KEY)
    if (HF_API_KEY) {
      return await callHuggingFace(prompt);
    }
    // Option 2: Local Ollama (no API key needed)
    else {
      return await callOllama(prompt);
    }
  } catch (err) {
    throw new Error(`LLM call failed: ${err.message}`);
  }
}

async function callHuggingFace(prompt) {
  const response = await axios.post(
    HF_INFERENCE_URL,
    {
      inputs: prompt,
      parameters: {
        max_new_tokens: 500,
        temperature: 0.3,  // Lower temp = more consistent output
        top_p: 0.9,
        return_full_text: false,
      },
    },
    {
      headers: {
        Authorization: `Bearer ${HF_API_KEY}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    }
  );

  const result = response.data[0]?.generated_text || '';
  return parseJSON(result);
}

async function callOllama(prompt) {
  // Requires: docker run -d -p 11434:11434 ollama/ollama && ollama run mistral
  const response = await axios.post('http://localhost:11434/api/generate', {
    model: 'mistral',
    prompt,
    stream: false,
    temperature: 0.3,
  });

  return parseJSON(response.data.response);
}

// ─── JSON PARSING (Robust) ──────────────────────────────────────────────────
function parseJSON(text) {
  // Find first { and last }
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');

  if (start === -1 || end === -1) {
    throw new Error('No JSON found in LLM response');
  }

  try {
    return JSON.parse(text.substring(start, end + 1));
  } catch (err) {
    console.error('[JSON Parse Error]', text.substring(start, end + 1));
    throw new Error('Invalid JSON from LLM');
  }
}

// ─── NORMALIZATION ──────────────────────────────────────────────────────────
function normalizeExtraction(extracted, rawData) {
  return {
    business_name: (extracted.business_name || '').trim(),
    phone_number: normalizePhoneNumber(extracted.phone_number),
    address: (extracted.address || '').trim(),
    city: (extracted.city || '').trim(),
    state: (extracted.state || '').trim(),
    country: normalizeCountry(extracted.country),
    country_code: getCountryCode(extracted.country),
    website: normalizeURL(extracted.website),
    operating_hours: extracted.operating_hours,
    description: (extracted.description || '').trim(),
    keywords: extracted.keywords || [],
    data_quality: extracted.data_quality || {},
  };
}

function normalizePhoneNumber(phone) {
  if (!phone) return null;

  // Remove all non-digits except +
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Add country code if missing
  if (cleaned.length === 10 && !cleaned.startsWith('+')) {
    // Assume Nigeria, Ghana, or Kenya based on context
    cleaned = '+234' + cleaned.substring(1);
  }

  // Validate: should be 10-15 digits total
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 10 || digitsOnly.length > 15) {
    return null;
  }

  return cleaned;
}

function normalizeCountry(country) {
  const countryMap = {
    'ng': 'Nigeria', 'nigeri': 'Nigeria', 'ng': 'Nigeria',
    'gh': 'Ghana', 'ghana': 'Ghana',
    'ke': 'Kenya', 'keny': 'Kenya',
  };

  if (!country) return null;
  const lower = country.toLowerCase();

  for (const [key, value] of Object.entries(countryMap)) {
    if (lower.includes(key)) {
      return value;
    }
  }

  return country.charAt(0).toUpperCase() + country.slice(1);
}

function getCountryCode(country) {
  const codes = {
    'Nigeria': 'NG',
    'Ghana': 'GH',
    'Kenya': 'KE',
  };
  return codes[country] || null;
}

function normalizeURL(url) {
  if (!url || typeof url !== 'string') return null;
  if (url === 'null' || url === 'None' || url === '') return null;

  try {
    new URL(url.startsWith('http') ? url : `https://${url}`);
    return url.startsWith('http') ? url : `https://${url}`;
  } catch {
    return null;
  }
}

// ─── AUTO-CATEGORIZE ────────────────────────────────────────────────────────
function autoDetectCategory(normalized) {
  const searchText = [
    normalized.business_name,
    normalized.description,
    (normalized.keywords || []).join(' '),
  ]
    .join(' ')
    .toLowerCase();

  for (const [category, keywords] of Object.entries(CATEGORY_MAPPING)) {
    if (keywords.some(kw => searchText.includes(kw))) {
      return category;
    }
  }

  return 'Services';  // Default category
}

// ─── CONFIDENCE SCORING ─────────────────────────────────────────────────────
/**
 * Calculate confidence score (0.0–1.0) based on data quality & source
 */
function calculateConfidence(normalized, source, rawData) {
  let score = 0.5;  // Base score

  // Source authority weight
  const sourceWeights = {
    google_maps: 0.25,
    openstreetmap: 0.15,
    web_crawl: 0.10,
    linkedin: 0.20,
    unknown: 0.05,
  };
  score += sourceWeights[source] || sourceWeights.unknown;

  // Data completeness
  const quality = normalized.data_quality || {};
  if (quality.completeness) {
    score += quality.completeness * 0.20;
  } else {
    const hasName = normalized.business_name && normalized.business_name.length > 2;
    const hasPhone = normalized.phone_number !== null;
    const hasAddress = normalized.address && normalized.address.length > 5;
    const hasCity = normalized.city && normalized.city.length > 1;

    const completeness = [hasName, hasPhone, hasAddress, hasCity].filter(Boolean).length / 4;
    score += completeness * 0.20;
  }

  // Phone verification (will add +0.15 if SMS confirms)
  // For now, check if phone looks valid
  if (normalized.phone_number) {
    const phoneDigits = normalized.phone_number.replace(/\D/g, '');
    if (phoneDigits.length >= 10 && phoneDigits.length <= 15) {
      score += 0.10;  // Valid format (full verification happens later)
    }
  }

  // Geo data
  if (rawData.latitude && rawData.longitude) {
    score += 0.08;
  }

  // Multi-field match (website, description, etc)
  const extraFields = [normalized.website, normalized.operating_hours, normalized.description].filter(
    x => x && x.length > 0
  ).length;
  score += Math.min(extraFields * 0.05, 0.15);

  // Cap at 1.0
  return Math.min(score, 1.0).toFixed(2);
}

function getConfidenceBreakdown(normalized, source) {
  return {
    source_authority: {
      value: { google_maps: 0.25, openstreetmap: 0.15, web_crawl: 0.10 }[source] || 0.05,
      reason: `Data from ${source}`,
    },
    data_completeness: {
      value: normalized.data_quality?.completeness || 0.5,
      reason: 'Has name, phone, address, city',
    },
    phone_validity: {
      value: normalized.phone_number ? 0.10 : 0,
      reason: normalized.phone_number ? 'Valid phone format' : 'No phone',
    },
    geo_data: {
      value: normalized.latitude && normalized.longitude ? 0.08 : 0,
      reason: 'Latitude/longitude available',
    },
  };
}

// ─── PHONE VERIFICATION (SMS PING) ──────────────────────────────────────────
/**
 * Verify phone number is active via SMS API
 * Cost: ~$0.01 per SMS
 */
async function verifyPhoneNumber(phoneNumber) {
  if (!phoneNumber) return { verified: false, reason: 'No phone' };

  try {
    const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

    // Send silent verification SMS
    const message = await twilio.messages.create({
      body: 'Vukafia business listing verification. Reply to confirm.',
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phoneNumber,
    });

    // If SMS sent successfully, number is valid
    return {
      verified: true,
      reason: 'SMS delivered',
      sms_sid: message.sid,
      verified_at: new Date(),
    };
  } catch (err) {
    return {
      verified: false,
      reason: err.message,
    };
  }
}

// ─── GEO VERIFICATION (Google Geocoding) ────────────────────────────────────
/**
 * Verify address via Google Maps geocoding
 * Cost: ~$0.005 per call (free tier: 25K/day)
 */
async function verifyGeoData(address, city, country) {
  if (!address || !city) return { verified: false };

  try {
    const googleMapsClient = require('@googlemaps/js-client-library');

    const geocoder = new googleMapsClient.Geocoder({
      key: process.env.GOOGLE_MAPS_API_KEY,
    });

    const result = await geocoder.geocode({
      address: `${address}, ${city}, ${country}`,
    });

    if (result.results.length > 0) {
      const { lat, lng } = result.results[0].geometry.location;
      return {
        verified: true,
        latitude: lat,
        longitude: lng,
        formatted_address: result.results[0].formatted_address,
      };
    }

    return { verified: false, reason: 'Address not found' };
  } catch (err) {
    return { verified: false, reason: err.message };
  }
}

// ─── DEDUPLICATION ──────────────────────────────────────────────────────────
/**
 * Check if listing already exists (avoid duplicates)
 */
async function checkDuplicate(normalized, db) {
  // Look for exact phone match
  if (normalized.phone_number) {
    const existing = await db('ai_discovered_listings')
      .where('phone_number', normalized.phone_number)
      .where('country_code', normalized.country_code)
      .first();

    if (existing) {
      return { isDuplicate: true, existingId: existing.id, reason: 'phone_match' };
    }
  }

  // Look for name + city match (fuzzy)
  if (normalized.business_name && normalized.city) {
    const nameNorm = normalized.business_name.toLowerCase().trim();
    const existing = await db('ai_discovered_listings')
      .whereRaw('LOWER(business_name) = ?', [nameNorm])
      .where('city', normalized.city)
      .where('country_code', normalized.country_code)
      .first();

    if (existing) {
      return { isDuplicate: true, existingId: existing.id, reason: 'name_city_match' };
    }
  }

  return { isDuplicate: false };
}

// ─── EXPORT ────────────────────────────────────────────────────────────────
module.exports = {
  extractBusinessData,
  verifyPhoneNumber,
  verifyGeoData,
  checkDuplicate,
  calculateConfidence,
  normalizePhoneNumber,
};
