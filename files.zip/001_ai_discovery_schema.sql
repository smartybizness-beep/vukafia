/**
 * Vukafia AI Discovery & Claiming Schema Migration
 * Run this AFTER your initial db.js schema setup
 */

-- ═════════════════════════════════════════════════════════════════════════════
-- TABLE: ai_discovered_listings
-- Raw extracted data from AI crawls (before manual review)
-- ═════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS ai_discovered_listings (
  id SERIAL PRIMARY KEY,
  
  -- Discovery metadata
  source VARCHAR(50) NOT NULL,           -- 'google_maps', 'openstreetmap', 'web_crawl'
  source_id VARCHAR(255) UNIQUE,         -- External ID (Google Place ID, OSM way ID, etc)
  discovered_at TIMESTAMP DEFAULT NOW(),
  
  -- Extracted raw data
  raw_data JSON NOT NULL,                -- Original crawled data
  
  -- Normalized fields
  business_name VARCHAR(255) NOT NULL,
  phone_number VARCHAR(20),
  country VARCHAR(100) NOT NULL,         -- 'Nigeria', 'Ghana', 'Kenya'
  country_code CHAR(2),                  -- 'NG', 'GH', 'KE'
  state VARCHAR(100),
  city VARCHAR(100),
  address TEXT,
  latitude DECIMAL(10, 6),
  longitude DECIMAL(10, 6),
  website VARCHAR(255),
  category VARCHAR(100),                 -- 'Electronics', 'Legal Services', etc
  
  -- Verification & confidence
  phone_verified BOOLEAN DEFAULT FALSE,
  phone_verification_date TIMESTAMP,
  geo_verified BOOLEAN DEFAULT FALSE,
  geo_verification_date TIMESTAMP,
  
  -- Confidence scoring
  confidence_score DECIMAL(3, 2),        -- 0.0 to 1.0
  confidence_breakdown JSON,             -- {source_weight: 0.2, phone: 0.1, geo: 0.1, ...}
  
  -- Status
  status VARCHAR(50) DEFAULT 'pending',  -- 'pending', 'added_to_directory', 'claimed', 'rejected'
  
  -- Link to live listing (once claimed)
  claimed_listing_id INT REFERENCES listings(id) ON DELETE SET NULL,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_source_id ON ai_discovered_listings(source_id);
CREATE INDEX IF NOT EXISTS idx_country ON ai_discovered_listings(country);
CREATE INDEX IF NOT EXISTS idx_phone ON ai_discovered_listings(phone_number);
CREATE INDEX IF NOT EXISTS idx_confidence ON ai_discovered_listings(confidence_score DESC);
CREATE INDEX IF NOT EXISTS idx_status ON ai_discovered_listings(status);

-- ═════════════════════════════════════════════════════════════════════════════
-- TABLE MODIFICATIONS: listings table
-- Add AI discovery tracking to main listings
-- ═════════════════════════════════════════════════════════════════════════════
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_discovered BOOLEAN DEFAULT FALSE;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_source VARCHAR(50);
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_source_id VARCHAR(255);
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_confidence_score DECIMAL(3, 2);
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_discovered_at TIMESTAMP;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS ai_extracted_data JSON;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS claim_token VARCHAR(255) UNIQUE;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS claim_token_expires_at TIMESTAMP;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS claim_verified_at TIMESTAMP;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS claimed_by_user_id INT REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE listings ADD COLUMN IF NOT EXISTS seller_corrections JSON;

-- ═════════════════════════════════════════════════════════════════════════════
-- TABLE: claim_attempts
-- Track who tried to claim listings (for analytics & fraud detection)
-- ═════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS claim_attempts (
  id SERIAL PRIMARY KEY,
  listing_id INT NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  
  -- Claim initiator
  phone_number VARCHAR(20) NOT NULL,
  ip_address VARCHAR(45),
  
  -- OTP verification
  otp_sent_at TIMESTAMP DEFAULT NOW(),
  otp_verified_at TIMESTAMP,
  otp_attempts INT DEFAULT 0,
  otp_verified BOOLEAN DEFAULT FALSE,
  
  -- Claim completion
  claim_started_at TIMESTAMP,
  claim_completed_at TIMESTAMP,
  claimed_by_user_id INT REFERENCES users(id) ON DELETE SET NULL,
  
  -- Status
  status VARCHAR(50) DEFAULT 'otp_sent',  -- 'otp_sent', 'otp_verified', 'claimed', 'expired', 'cancelled'
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_listing_phone ON claim_attempts(listing_id, phone_number);
CREATE INDEX IF NOT EXISTS idx_user_claim ON claim_attempts(claimed_by_user_id);

-- ═════════════════════════════════════════════════════════════════════════════
-- TABLE: data_sources
-- Track which data sources are available per country
-- ═════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS data_sources (
  id SERIAL PRIMARY KEY,
  
  country_code CHAR(2) NOT NULL,         -- 'NG', 'GH', 'KE'
  source_name VARCHAR(50) NOT NULL,      -- 'google_maps', 'openstreetmap', 'web_crawl'
  
  -- Configuration
  enabled BOOLEAN DEFAULT TRUE,
  api_key VARCHAR(255),                  -- Store API keys securely (encrypt in production)
  config JSON,                           -- Source-specific settings
  
  -- Usage tracking
  last_crawl_at TIMESTAMP,
  next_scheduled_crawl TIMESTAMP,
  records_crawled INT DEFAULT 0,
  records_imported INT DEFAULT 0,
  
  -- Rate limiting & cost tracking
  api_calls_this_month INT DEFAULT 0,
  api_cost_this_month DECIMAL(10, 2) DEFAULT 0.00,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  UNIQUE (country_code, source_name)
);

-- ═════════════════════════════════════════════════════════════════════════════
-- TABLE: crawl_jobs
-- Track each crawl job for monitoring & retry logic
-- ═════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS crawl_jobs (
  id SERIAL PRIMARY KEY,
  
  data_source_id INT REFERENCES data_sources(id),
  country_code CHAR(2) NOT NULL,
  source_name VARCHAR(50) NOT NULL,
  
  -- Job execution
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  
  -- Results
  records_found INT DEFAULT 0,
  records_processed INT DEFAULT 0,
  records_imported INT DEFAULT 0,
  records_duplicated INT DEFAULT 0,
  records_low_confidence INT DEFAULT 0,  -- Confidence < 0.5
  
  -- Error tracking
  status VARCHAR(50) DEFAULT 'pending',  -- 'pending', 'running', 'completed', 'failed'
  error_message TEXT,
  error_count INT DEFAULT 0,
  
  -- Cost tracking
  api_calls_used INT DEFAULT 0,
  estimated_cost DECIMAL(10, 2) DEFAULT 0.00,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_country_source ON crawl_jobs(country_code, source_name);
CREATE INDEX IF NOT EXISTS idx_crawl_status ON crawl_jobs(status);
