# 🌍 Vukafia AI Business Discovery System

**Complete implementation package** for auto-discovering and claiming AI-populated business listings in Nigeria, Ghana, and Kenya.

---

## 📋 What's Included

### Core Components
- ✅ **AI Extractor** (`services/ai_extractor.js`) — LLM-powered business data normalization
- ✅ **Crawl Worker** (`services/crawl_worker.js`) — Weekly automated business discovery (Bull queue)
- ✅ **Claiming API** (`routes/claiming.js`) — Business owner registration & listing claiming
- ✅ **Database Schema** (`migrations/`) — 5 new tables for tracking discovered data
- ✅ **Data Seeds** (`seeds/`) — Initialize data sources for 3 countries

### Documentation
- 📖 `QUICK_START.md` — Get running in 5 minutes
- 📖 `INTEGRATION_GUIDE.md` — Add to existing Vukafia project
- 📖 `SETUP_AI_DISCOVERY.md` — Full deployment guide
- 📖 `DEPENDENCIES.md` — Package requirements

---

## 🚀 Quick Start

### 1. Copy to Your Project
```bash
cp -r vukafia-implementation/* your-vukafia-folder/
```

### 2. Install Dependencies
```bash
npm install bull redis axios twilio
```

### 3. Update `.env`
```bash
AI_DISCOVERY_ENABLED=true
REDIS_URL=redis://localhost:6379
HF_API_KEY=your_hugging_face_key_here
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=+1234567890
GOOGLE_MAPS_API_KEY=your_google_maps_key
```

### 4. Run Migrations
```bash
npx knex migrate:latest
node seeds/seed_data_sources.js
```

### 5. Start Server
```bash
redis-server &  # Start Redis in background
npm run dev
```

---

## 📊 How It Works

### Weekly Crawl Cycle

```
Monday 12:00 AM (UTC) → Crawl starts
  ↓
1. Fetch from Google Maps (Nigeria, Ghana, Kenya)
2. Extract data via LLM (Hugging Face or local Ollama)
3. Normalize & validate phone numbers & addresses
4. Calculate confidence score (0.0–1.0)
  ↓
Score >= 0.7? → Add to directory (verified)
Score 0.5–0.7? → Add as pending (seller corrects)
Score < 0.5? → Discard (low quality)
  ↓
6. Store in ai_discovered_listings table
7. Queue phone verification via SMS
8. Send owner claim notifications
```

### Business Owner Claiming

```
1. Owner searches for their business
   GET /api/claiming/search?q=name&country=NG

2. Owner clicks "Claim This Listing"
   POST /api/claiming/initiate
   → OTP sent to business phone via SMS

3. Owner enters OTP
   POST /api/claiming/verify-otp
   → OTP verified

4. Owner registers account
   POST /api/claiming/complete
   → Account created, listing ownership transferred

5. Owner accesses dashboard
   Full seller dashboard unlocked ✓
```

---

## 🗂 File Structure

```
vukafia-implementation/
├── services/
│   ├── ai_extractor.js           # LLM extraction pipeline
│   └── crawl_worker.js           # Bull queue worker
│
├── routes/
│   └── claiming.js               # API endpoints (5 new routes)
│
├── migrations/
│   └── 001_ai_discovery_schema.sql    # DB schema (5 tables)
│
├── seeds/
│   └── seed_data_sources.js      # Initialize data sources
│
├── docs/
│   ├── QUICK_START.md            # 5-minute setup
│   ├── INTEGRATION_GUIDE.md       # Step-by-step integration
│   ├── SETUP_AI_DISCOVERY.md     # Full deployment guide
│   ├── DEPENDENCIES.md           # NPM packages needed
│   └── README.md                 # This file
│
└── README.md
```

---

## 🔗 New API Endpoints

### Search for Businesses
```
GET /api/claiming/search?q=electronics&country=NG
→ Returns: List of unclaimed AI-discovered listings
```

### Initiate Claim
```
POST /api/claiming/initiate
Body: { listing_id, phone_number }
→ Returns: OTP sent to phone, claim_token
```

### Verify OTP
```
POST /api/claiming/verify-otp
Body: { listing_id, claim_token, otp }
→ Returns: Verification successful
```

### Complete Claim & Register
```
POST /api/claiming/complete
Body: { listing_id, claim_token, owner_name, email, password }
→ Returns: JWT token, user_id, account created
```

### Get Listing Details
```
GET /api/claiming/listings/:id
→ Returns: Full listing details for claiming
```

---

## 📈 Expected Results (Month 1)

| Metric | Target |
|--------|--------|
| Businesses discovered | 2,000–5,000 |
| High confidence (>0.7) | 800–2,000 |
| Medium confidence (0.5–0.7) | 1,000–2,000 |
| Claims started | 50–200 |
| Claims completed | 20–100 |

---

## 💰 Cost Breakdown

### Per Month
| Service | Cost |
|---------|------|
| Google Maps API (~500 calls) | $7–15 |
| Hugging Face LLM (~1,500 extractions) | $0.15 |
| Twilio SMS (~50 OTPs) | $0.50 |
| OpenStreetMap | Free |
| Redis (managed) | $15 |
| **Total** | **~$23/month** |

### How to Save
- Use OpenStreetMap for 50% of crawls (free)
- Use local Ollama instead of Hugging Face (free but needs CPU)
- Reduce crawl frequency to bi-weekly

---

## 🔧 Configuration

### Confidence Score Calculation

Each discovered listing gets scored 0.0–1.0 based on:
- **Source authority** (Google Maps: 0.25, OSM: 0.15)
- **Data completeness** (name, phone, address, city)
- **Phone validity** (format checks)
- **Geo data** (latitude/longitude)
- **Extra fields** (website, hours, description)

```javascript
Score 0.75 example:
  Source authority: +0.25 (Google Maps)
  Data completeness: +0.20 (4/4 fields)
  Phone validity: +0.10 (valid format)
  Geo data: +0.08 (has coordinates)
  Extra fields: +0.12 (has website & description)
  = 0.75 ✓
```

### Customize Thresholds

Edit `services/crawl_worker.js`:
```javascript
// Line ~150: Adjust minimum confidence
if (confScore >= 0.7) {  // Change 0.7 to your threshold
  recordsImported++;
}
```

---

## 🐛 Troubleshooting

### Redis won't connect
```bash
# Start Redis
redis-server

# Or use managed Redis (Railway, Render)
# Set REDIS_URL in .env
```

### LLM timeout
```bash
# Option 1: Use local Ollama (free)
docker run -d -p 11434:11434 ollama/ollama
ollama run mistral

# Option 2: Check Hugging Face API status
# https://status.huggingface.co
```

### Google Maps quota exceeded
```
Error: OVER_QUERY_LIMIT
- Daily quota resets 12 AM PST
- Upgrade billing for higher quota
- Use OpenStreetMap (free) as fallback
```

### SMS not sending
```bash
# Verify Twilio credentials in .env
echo $TWILIO_ACCOUNT_SID   # Should be ACxxxxxxx
echo $TWILIO_PHONE_NUMBER  # Should be +XXXXXXXXXX
# Check account balance: https://www.twilio.com/console
```

---

## 📚 Implementation Steps

### Day 1: Local Setup
- [ ] Copy files to your Vukafia project
- [ ] `npm install bull redis axios twilio`
- [ ] Update `.env`
- [ ] Run migrations
- [ ] Run seeds

### Day 2: Testing
- [ ] Start Redis & server
- [ ] Test search endpoint
- [ ] Test claim flow end-to-end
- [ ] Verify SMS sending

### Day 3: Deploy
- [ ] Push to GitHub
- [ ] Deploy to Railway/Render
- [ ] Run migrations on prod
- [ ] Monitor first crawl

### Week 2: Monitor & Optimize
- [ ] Watch crawl_jobs table
- [ ] Track API costs
- [ ] Adjust confidence thresholds
- [ ] Monitor claim completion rate

---

## 📞 Support

- **Setup issues?** → `INTEGRATION_GUIDE.md`
- **Deployment help?** → `SETUP_AI_DISCOVERY.md`
- **API questions?** → Check inline comments in route files
- **Cost concerns?** → See cost breakdown section above

---

## 🎯 Next Features (Phase 2)

- [ ] Multi-language support (Yoruba, Twi, Swahili)
- [ ] WhatsApp Business API integration
- [ ] Advanced analytics dashboard
- [ ] Seller notifications & reminders
- [ ] Duplicate detection & merging
- [ ] Manual review queue for medium-confidence listings

---

## 📄 License

Part of Vukafia — Pan-African B2B Marketplace

---

## 🚀 Ready to Go!

Follow the **QUICK_START.md** or **INTEGRATION_GUIDE.md** to begin.

Questions? Check the docs folder.

**Let's discover Africa's businesses! 🌍**
