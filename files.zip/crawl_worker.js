/**
 * services/crawl_worker.js
 * 
 * Bull job queue worker for weekly business crawls
 * Handles Google Maps, OpenStreetMap, and web crawls per country
 * 
 * Install: npm install bull redis axios
 */

'use strict';

const Queue = require('bull');
const axios = require('axios');
const { extractBusinessData, verifyPhoneNumber, verifyGeoData, checkDuplicate } = require('./ai_extractor');

const db = require('../db');

// ─── QUEUE SETUP ──────────────────────────────────────────────────────────
const redisURL = process.env.REDIS_URL || 'redis://127.0.0.1:6379';

const crawlQueue = new Queue('business-crawl', redisURL, {
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000,
    },
    removeOnComplete: true,
  },
});

const verificationQueue = new Queue('phone-verification', redisURL, {
  defaultJobOptions: {
    attempts: 2,
    removeOnComplete: true,
  },
});

// ─── CRAWL JOB PROCESSOR ────────────────────────────────────────────────────
crawlQueue.process(1, async job => {
  const { countryCode, source } = job.data;

  console.log(`[Crawl Job] Starting: ${countryCode} from ${source}`);

  try {
    // 1. Get data source config
    const dataSource = await getDataSourceConfig(countryCode, source);
    if (!dataSource.enabled) {
      throw new Error(`Data source ${source} disabled for ${countryCode}`);
    }

    // 2. Start crawl job record
    const crawlJob = await db('crawl_jobs').insert({
      data_source_id: dataSource.id,
      country_code: countryCode,
      source_name: source,
      started_at: new Date(),
      status: 'running',
    });

    // 3. Fetch raw data based on source
    let rawBusinesses = [];
    let apiCallsUsed = 0;

    if (source === 'google_maps') {
      const result = await fetchGoogleMapsBusiness(countryCode, dataSource);
      rawBusinesses = result.businesses;
      apiCallsUsed = result.apiCalls;
    } else if (source === 'openstreetmap') {
      const result = await fetchOpenStreetMapBusinesses(countryCode);
      rawBusinesses = result.businesses;
      apiCallsUsed = result.apiCalls;
    } else if (source === 'web_crawl') {
      const result = await fetchWebCrawlBusinesses(countryCode);
      rawBusinesses = result.businesses;
      apiCallsUsed = result.apiCalls;
    }

    console.log(`[Crawl] Found ${rawBusinesses.length} businesses from ${source}`);

    // 4. Process each business: extract, verify, deduplicate
    let recordsProcessed = 0;
    let recordsImported = 0;
    let recordsDuplicated = 0;
    let recordsLowConfidence = 0;

    for (const rawBusiness of rawBusinesses) {
      try {
        recordsProcessed++;

        // Extract & normalize
        const { success, extracted, error } = await extractBusinessData(rawBusiness, source);
        if (!success) {
          console.warn(`[Extract Error] ${error}`, rawBusiness);
          continue;
        }

        // Check confidence threshold (>= 0.5 to proceed, >= 0.7 to auto-add)
        const confScore = parseFloat(extracted.confidence_score);
        if (confScore < 0.5) {
          recordsLowConfidence++;
          continue;
        }

        // Check for duplicates
        const { isDuplicate, reason } = await checkDuplicate(extracted, db);
        if (isDuplicate) {
          recordsDuplicated++;
          continue;
        }

        // Insert into ai_discovered_listings
        const discoveredId = await db('ai_discovered_listings').insert({
          source,
          source_id: rawBusiness.id || rawBusiness.place_id,
          raw_data: JSON.stringify(rawBusiness),
          business_name: extracted.business_name,
          phone_number: extracted.phone_number,
          country: extracted.country,
          country_code: extracted.country_code,
          state: extracted.state,
          city: extracted.city,
          address: extracted.address,
          latitude: extracted.latitude,
          longitude: extracted.longitude,
          website: extracted.website,
          category: extracted.category,
          confidence_score: confScore,
          confidence_breakdown: JSON.stringify(extracted.confidence_breakdown),
          status: confScore >= 0.7 ? 'added_to_directory' : 'pending',
        });

        // If high confidence (>= 0.7), auto-create listing
        if (confScore >= 0.7) {
          const listingId = await createListingFromDiscoveredData(extracted, discoveredId, source);

          // Update link
          await db('ai_discovered_listings').where('id', discoveredId).update({
            claimed_listing_id: listingId,
          });

          recordsImported++;

          // Queue phone verification if >= 0.7 confidence
          await verificationQueue.add({
            listingId,
            phoneNumber: extracted.phone_number,
            country: extracted.country,
          });
        } else {
          // Low confidence (0.5–0.7): keep pending, let seller correct
          recordsImported++;
        }
      } catch (err) {
        console.error('[Process Business Error]', err.message, rawBusiness);
      }
    }

    // 5. Update crawl job record with results
    await db('crawl_jobs').where('id', crawlJob.id).update({
      completed_at: new Date(),
      status: 'completed',
      records_found: rawBusinesses.length,
      records_processed: recordsProcessed,
      records_imported: recordsImported,
      records_duplicated: recordsDuplicated,
      records_low_confidence: recordsLowConfidence,
      api_calls_used: apiCallsUsed,
      estimated_cost: estimateAPICost(source, apiCallsUsed),
    });

    // 6. Update data source
    const costEstimate = estimateAPICost(source, apiCallsUsed);
    await db('data_sources').where('id', dataSource.id).update({
      last_crawl_at: new Date(),
      next_scheduled_crawl: db.raw('DATE_ADD(NOW(), INTERVAL 7 DAY)'),
      records_crawled: db.raw(`records_crawled + ${recordsProcessed}`),
      records_imported: db.raw(`records_imported + ${recordsImported}`),
      api_calls_this_month: db.raw(`api_calls_this_month + ${apiCallsUsed}`),
      api_cost_this_month: db.raw(`api_cost_this_month + ${costEstimate}`),
    });

    console.log(
      `[Crawl Complete] ${countryCode} from ${source}: ${recordsImported}/${recordsProcessed} imported`
    );

    return {
      success: true,
      countryCode,
      source,
      recordsProcessed,
      recordsImported,
      recordsDuplicated,
      recordsLowConfidence,
      apiCallsUsed,
      estimatedCost: costEstimate,
    };
  } catch (err) {
    console.error(`[Crawl Job Error] ${countryCode}/${source}:`, err.message);

    // Log error in crawl_jobs
    await db('crawl_jobs')
      .where({ country_code: countryCode, source_name: source, status: 'running' })
      .update({
        status: 'failed',
        error_message: err.message,
        completed_at: new Date(),
      });

    throw err;  // Let Bull retry
  }
});

// ─── DATA FETCHING FUNCTIONS ────────────────────────────────────────────────

/**
 * Fetch from Google Maps Places API
 * Cost: ~$0.015–0.06 per query depending on data
 */
async function fetchGoogleMapsBusiness(countryCode, dataSource) {
  const countries = { NG: 'Nigeria', GH: 'Ghana', KE: 'Kenya' };
  const countryName = countries[countryCode];

  if (!countryName) throw new Error(`Unknown country code: ${countryCode}`);

  const categories = [
    'electronics',
    'retail',
    'services',
    'legal services',
    'health services',
    'construction',
    'automotive',
  ];

  const businesses = [];
  let apiCalls = 0;

  for (const category of categories) {
    try {
      const response = await axios.get('https://maps.googleapis.com/maps/api/place/textsearch/json', {
        params: {
          query: `${category} businesses in ${countryName}`,
          key: process.env.GOOGLE_MAPS_API_KEY,
          type: 'business',
        },
      });

      apiCalls += 1;
      businesses.push(...(response.data.results || []));

      // Handle pagination if next_page_token exists
      while (response.data.next_page_token) {
        await new Promise(resolve => setTimeout(resolve, 2000));  // Rate limiting
        const nextResponse = await axios.get('https://maps.googleapis.com/maps/api/place/textsearch/json', {
          params: {
            pagetoken: response.data.next_page_token,
            key: process.env.GOOGLE_MAPS_API_KEY,
          },
        });
        apiCalls += 1;
        businesses.push(...(nextResponse.data.results || []));
      }
    } catch (err) {
      console.error(`[Google Maps Error] ${category}:`, err.message);
    }
  }

  return { businesses, apiCalls };
}

/**
 * Fetch from OpenStreetMap (free, no API key needed)
 */
async function fetchOpenStreetMapBusinesses(countryCode) {
  const countries = { NG: 'Nigeria', GH: 'Ghana', KE: 'Kenya' };
  const countryName = countries[countryCode];

  const bbox = getBoundingBox(countryCode);  // Pre-defined bbox for each country
  const businesses = [];
  let apiCalls = 0;

  try {
    // Query for shops, offices, services
    const query = `[bbox:${bbox}]; (node["shop"]; node["office"]; node["amenity"~"restaurant|cafe|hotel"]; way["shop"]; way["office"];); out center;`;

    const response = await axios.get('https://overpass-api.de/api/interpreter', {
      params: { data: query },
      timeout: 30000,
    });

    apiCalls += 1;

    // Parse OSM response
    const elements = response.data.elements || [];
    for (const element of elements) {
      const center = element.center || { lat: element.lat, lon: element.lon };
      businesses.push({
        id: `osm_${element.id}`,
        name: element.tags?.name || element.tags?.business || 'Unnamed',
        phone: element.tags?.phone,
        address: element.tags?.['addr:street'] || '',
        city: element.tags?.['addr:city'] || '',
        website: element.tags?.website,
        latitude: center.lat,
        longitude: center.lon,
        type: element.tags?.shop || element.tags?.office || 'business',
      });
    }
  } catch (err) {
    console.error('[OpenStreetMap Error]', err.message);
  }

  return { businesses, apiCalls };
}

/**
 * Web crawl (scrape business listings from Instagram, Facebook, etc.)
 * Keep this simple for MVP
 */
async function fetchWebCrawlBusinesses(countryCode) {
  // For MVP, return empty array
  // In production, integrate with Instagram scraper, Facebook graph API, etc.
  return { businesses: [], apiCalls: 0 };
}

// ─── PHONE VERIFICATION WORKER ──────────────────────────────────────────────
verificationQueue.process(async job => {
  const { listingId, phoneNumber, country } = job.data;

  console.log(`[Phone Verify] Listing ${listingId}: ${phoneNumber}`);

  try {
    const result = await verifyPhoneNumber(phoneNumber);

    // Update listing with verification result
    await db('listings').where('id', listingId).update({
      phone_verified: result.verified,
      phone_verification_date: new Date(),
    });

    if (result.verified) {
      console.log(`[Phone Verified] ${phoneNumber}`);
    } else {
      console.warn(`[Phone Not Verified] ${phoneNumber}: ${result.reason}`);
    }

    return result;
  } catch (err) {
    console.error('[Verification Error]', err.message);
    throw err;  // Let Bull retry
  }
});

// ─── HELPER FUNCTIONS ──────────────────────────────────────────────────────

function getDataSourceConfig(countryCode, source) {
  return db('data_sources')
    .where({ country_code: countryCode, source_name: source })
    .first();
}

async function createListingFromDiscoveredData(extracted, discoveredId, source) {
  const user = await db('users')
    .where('role', 'admin')
    .first();  // Assign to admin initially

  const listingId = await db('listings').insert({
    user_id: user.id,
    type: 'product',  // Default to product; seller can change
    region: getRegionFromCountry(extracted.country),
    country: extracted.country,
    country_code: extracted.country_code,
    state: extracted.state,
    city: extracted.city,
    name: extracted.business_name,
    category: extracted.category,
    description: extracted.description,
    phone: extracted.phone_number,
    email: null,
    website: extracted.website,
    latitude: extracted.latitude,
    longitude: extracted.longitude,
    verified: false,
    featured: false,
    is_new: true,
    active: true,
    emoji: getCategoryEmoji(extracted.category),

    // AI discovery fields
    ai_discovered: true,
    ai_source: source,
    ai_source_id: extracted.source_id,
    ai_confidence_score: extracted.confidence_score,
    ai_discovered_at: new Date(),
    ai_extracted_data: JSON.stringify(extracted),
  });

  return listingId[0];
}

function getRegionFromCountry(country) {
  const regions = {
    Nigeria: 'West Africa',
    Ghana: 'West Africa',
    Kenya: 'East Africa',
  };
  return regions[country] || 'Africa';
}

function getCategoryEmoji(category) {
  const emojis = {
    electronics: '📱',
    'legal services': '⚖️',
    'health & medical': '🏥',
    'retail & trading': '🛍️',
    'auto & transport': '🚗',
    'food & beverage': '🍽️',
    'agriculture & farming': '🌾',
    education: '🎓',
    construction: '🏗️',
  };
  return emojis[category] || '🏢';
}

function getBoundingBox(countryCode) {
  const bboxes = {
    NG: '2.668,4.27,14.68,13.89',  // Nigeria
    GH: '-3.24,1.0,1.27,11.2',     // Ghana
    KE: '29.34,-4.68,41.86,4.62',  // Kenya
  };
  return bboxes[countryCode] || '';
}

function estimateAPICost(source, apiCalls) {
  const costPerCall = {
    google_maps: 0.015,
    openstreetmap: 0.0,
    web_crawl: 0.0,
  };
  return (costPerCall[source] || 0) * apiCalls;
}

// ─── SCHEDULED JOBS ────────────────────────────────────────────────────────

/**
 * Schedule weekly crawls for each country + data source
 * Call this in your server.js startup
 */
async function scheduleWeeklyCrawls() {
  const dataSources = await db('data_sources').where('enabled', true);

  console.log(`[Crawl Scheduler] Scheduling ${dataSources.length} data sources`);

  for (const source of dataSources) {
    // Schedule every 7 days
    await crawlQueue.add(
      {
        countryCode: source.country_code,
        source: source.source_name,
      },
      {
        repeat: {
          every: 7 * 24 * 60 * 60 * 1000,  // 7 days in ms
        },
        jobId: `crawl-${source.country_code}-${source.source_name}`,
      }
    );

    console.log(`[Scheduled] Weekly crawl: ${source.country_code} from ${source.source_name}`);
  }
}

// ─── EXPORT ────────────────────────────────────────────────────────────────
module.exports = {
  crawlQueue,
  verificationQueue,
  scheduleWeeklyCrawls,
};
