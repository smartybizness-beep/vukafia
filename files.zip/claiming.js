/**
 * routes/claiming.js
 * 
 * Business claiming workflow for AI-discovered listings
 * Flow: 1) Initiate claim → 2) Verify OTP → 3) Complete claim
 */

'use strict';

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const axios = require('axios');

const db = require('../db');
const { authMiddleware } = require('../middleware/auth');

// ─── CLAIM INITIATION ──────────────────────────────────────────────────────
/**
 * POST /api/claiming/initiate
 * 
 * Business owner initiates claim for an AI-discovered listing
 * 
 * Body: {
 *   listing_id: 123,
 *   phone_number: "+2348012345678"
 * }
 * 
 * Returns: { success: true, message: "OTP sent to phone", otp_expires_in: 600 }
 */
router.post('/initiate', async (req, res) => {
  try {
    const { listing_id, phone_number } = req.body;

    // Validate input
    if (!listing_id || !phone_number) {
      return res.status(400).json({ error: 'listing_id and phone_number required' });
    }

    // Check listing exists and is AI-discovered
    const listing = await db('listings')
      .where('id', listing_id)
      .where('ai_discovered', true)
      .first();

    if (!listing) {
      return res.status(404).json({
        error: 'Listing not found or cannot be claimed',
      });
    }

    // Check if already claimed
    if (listing.claimed_by_user_id) {
      return res.status(403).json({
        error: 'This listing has already been claimed',
      });
    }

    // Normalize phone number
    const normalizedPhone = normalizePhoneNumber(phone_number);
    if (!normalizedPhone) {
      return res.status(400).json({ error: 'Invalid phone number format' });
    }

    // Check phone matches listing phone
    const listingPhone = listing.phone ? normalizePhoneNumber(listing.phone) : null;
    if (listingPhone && listingPhone !== normalizedPhone) {
      return res.status(403).json({
        error: 'Phone number does not match the business listing phone',
      });
    }

    // Generate OTP (6 digits) and token
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const claimToken = crypto.randomBytes(32).toString('hex');
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);  // 10 min expiry

    // Store claim attempt
    const claimAttempt = await db('claim_attempts').insert({
      listing_id,
      phone_number: normalizedPhone,
      ip_address: req.ip,
      otp_sent_at: new Date(),
      status: 'otp_sent',
    });

    // Store OTP (in production, use Redis with expiry)
    await db('cache').insert({
      key: `otp_${claimAttempt.id}`,
      value: otp,
      expires_at: otpExpiresAt,
    });

    // Store claim token
    await db('listings').where('id', listing_id).update({
      claim_token: claimToken,
      claim_token_expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000),  // 24hr expiry
    });

    // Send OTP via SMS
    await sendSMSOTP(normalizedPhone, otp, listing.business_name);

    // Log success
    console.log(`[Claim Initiated] Listing ${listing_id}, Phone: ${normalizedPhone}`);

    res.json({
      success: true,
      message: `OTP sent to ${normalizedPhone}`,
      otp_expires_in: 600,  // seconds
      claim_token: claimToken,  // Client needs this for verification step
    });
  } catch (err) {
    console.error('[Claim Initiate Error]', err);
    res.status(500).json({ error: 'Failed to initiate claim' });
  }
});

// ─── OTP VERIFICATION ──────────────────────────────────────────────────────
/**
 * POST /api/claiming/verify-otp
 * 
 * Verify OTP before allowing claim completion
 * 
 * Body: {
 *   listing_id: 123,
 *   claim_token: "abc123...",
 *   otp: "123456"
 * }
 * 
 * Returns: { success: true, message: "OTP verified", next_step: "complete_claim" }
 */
router.post('/verify-otp', async (req, res) => {
  try {
    const { listing_id, claim_token, otp } = req.body;

    if (!listing_id || !claim_token || !otp) {
      return res.status(400).json({ error: 'listing_id, claim_token, and otp required' });
    }

    // Get listing
    const listing = await db('listings').where('id', listing_id).first();
    if (!listing) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    // Verify claim token not expired
    if (!listing.claim_token_expires_at || new Date() > listing.claim_token_expires_at) {
      return res.status(403).json({
        error: 'Claim token expired. Please initiate claim again.',
      });
    }

    // Verify claim token matches
    if (listing.claim_token !== claim_token) {
      return res.status(403).json({ error: 'Invalid claim token' });
    }

    // Get OTP from attempt
    const claimAttempt = await db('claim_attempts')
      .where('listing_id', listing_id)
      .orderBy('id', 'desc')
      .first();

    if (!claimAttempt) {
      return res.status(404).json({ error: 'No claim attempt found' });
    }

    // Check OTP expiry
    if (new Date() > claimAttempt.otp_sent_at + 10 * 60 * 1000) {
      return res.status(403).json({ error: 'OTP expired' });
    }

    // Verify OTP
    const cachedOTP = await db('cache').where('key', `otp_${claimAttempt.id}`).first();
    if (!cachedOTP || cachedOTP.value !== otp) {
      // Increment attempts
      await db('claim_attempts').where('id', claimAttempt.id).update({
        otp_attempts: claimAttempt.otp_attempts + 1,
      });

      // Lock after 3 failed attempts
      if (claimAttempt.otp_attempts >= 2) {
        await db('claim_attempts').where('id', claimAttempt.id).update({
          status: 'expired',
        });
        return res.status(403).json({
          error: 'Too many OTP attempts. Please initiate claim again.',
        });
      }

      return res.status(403).json({ error: 'Incorrect OTP' });
    }

    // Mark OTP verified
    await db('claim_attempts').where('id', claimAttempt.id).update({
      otp_verified: true,
      otp_verified_at: new Date(),
      status: 'otp_verified',
    });

    // Clean up cached OTP
    await db('cache').where('key', `otp_${claimAttempt.id}`).delete();

    console.log(`[OTP Verified] Listing ${listing_id}`);

    res.json({
      success: true,
      message: 'OTP verified successfully',
      next_step: 'complete_claim',
    });
  } catch (err) {
    console.error('[OTP Verify Error]', err);
    res.status(500).json({ error: 'OTP verification failed' });
  }
});

// ─── COMPLETE CLAIM & REGISTER USER ────────────────────────────────────────
/**
 * POST /api/claiming/complete
 * 
 * Complete the claim by registering business owner account
 * 
 * Body: {
 *   listing_id: 123,
 *   claim_token: "abc123...",
 *   owner_name: "John Doe",
 *   email: "john@email.com",
 *   password: "strong_password",
 *   phone_number: "+2348012345678"
 * }
 * 
 * Returns: { success: true, user_id: 456, jwt_token: "...", listing_id: 123 }
 */
router.post('/complete', async (req, res) => {
  try {
    const { listing_id, claim_token, owner_name, email, password, phone_number } = req.body;

    if (!listing_id || !claim_token || !owner_name || !email || !password) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Get listing
    const listing = await db('listings').where('id', listing_id).first();
    if (!listing) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    // Verify claim token
    if (listing.claim_token !== claim_token || !listing.claim_token_expires_at) {
      return res.status(403).json({ error: 'Invalid or expired claim token' });
    }

    if (new Date() > listing.claim_token_expires_at) {
      return res.status(403).json({ error: 'Claim token expired' });
    }

    // Check claim attempt was OTP verified
    const claimAttempt = await db('claim_attempts')
      .where('listing_id', listing_id)
      .where('status', 'otp_verified')
      .orderBy('id', 'desc')
      .first();

    if (!claimAttempt) {
      return res.status(403).json({
        error: 'OTP must be verified before completing claim',
      });
    }

    // Check email not already in use
    const existingUser = await db('users').where('email', email).first();
    if (existingUser) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    // Create user account
    const bcrypt = require('bcryptjs');
    const passwordHash = await bcrypt.hash(password, 10);

    const userId = await db('users').insert({
      name: owner_name,
      email,
      phone: normalizePhoneNumber(phone_number) || listing.phone,
      password_hash: passwordHash,
      role: 'seller',
      active: true,
      plan: 'free',
    });

    // Update listing
    await db('listings').where('id', listing_id).update({
      user_id: userId[0],
      claimed_by_user_id: userId[0],
      claim_verified_at: new Date(),
      verified: true,  // Auto-verify AI-discovered listings
      is_new: false,
      claim_token: null,
      claim_token_expires_at: null,
    });

    // Update claim attempt
    await db('claim_attempts').where('id', claimAttempt.id).update({
      claim_started_at: new Date(),
      claim_completed_at: new Date(),
      claimed_by_user_id: userId[0],
      status: 'claimed',
    });

    // Generate JWT
    const token = jwt.sign(
      { userId: userId[0], email, role: 'seller' },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    console.log(`[Claim Complete] Listing ${listing_id}, User ${userId[0]}`);

    res.json({
      success: true,
      message: 'Claim completed successfully',
      user_id: userId[0],
      jwt_token: token,
      listing_id,
    });
  } catch (err) {
    console.error('[Claim Complete Error]', err);
    res.status(500).json({ error: 'Failed to complete claim' });
  }
});

// ─── GET UNVERIFIED LISTINGS (Discovery) ────────────────────────────────────
/**
 * GET /api/claiming/search?q=business&country=NG
 * 
 * Business owner searches for their listing
 * Shows both verified and unverified AI-discovered listings
 */
router.get('/search', async (req, res) => {
  try {
    const { q, country } = req.query;

    if (!q || !country) {
      return res.status(400).json({ error: 'q (search term) and country required' });
    }

    // Search AI-discovered listings matching query
    const listings = await db('listings')
      .where('ai_discovered', true)
      .where('country_code', country)
      .where(function() {
        this.whereRaw('LOWER(name) LIKE ?', [`%${q.toLowerCase()}%`])
          .orWhereRaw('LOWER(description) LIKE ?', [`%${q.toLowerCase()}%`]);
      })
      .orderBy('ai_confidence_score', 'desc')
      .limit(20)
      .select(
        'id',
        'name',
        'city',
        'state',
        'phone',
        'category',
        'verified',
        'ai_confidence_score',
        'ai_discovered_at'
      );

    res.json({
      success: true,
      count: listings.length,
      listings: listings.map(l => ({
        id: l.id,
        name: l.name,
        location: `${l.city}, ${l.state}`,
        category: l.category,
        phone: l.phone,
        verified: l.verified,
        confidence: l.ai_confidence_score,
        can_claim: !l.verified,  // Only unverified listings can be claimed
      })),
    });
  } catch (err) {
    console.error('[Search Error]', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

// ─── GET SINGLE LISTING CLAIM VIEW ─────────────────────────────────────────
/**
 * GET /api/claiming/listings/:id
 * 
 * View AI-discovered listing details before claiming
 */
router.get('/listings/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const listing = await db('listings').where('id', id).first();
    if (!listing || !listing.ai_discovered) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    const extractedData = listing.ai_extracted_data ? JSON.parse(listing.ai_extracted_data) : {};

    res.json({
      success: true,
      listing: {
        id: listing.id,
        name: listing.name,
        address: listing.address,
        city: listing.city,
        state: listing.state,
        phone: listing.phone,
        website: listing.website,
        category: listing.category,
        description: listing.description,
        verified: listing.verified,
        ai_confidence: listing.ai_confidence_score,
        ai_source: listing.ai_source,

        // Show extracted fields in case seller wants to review
        extracted: extractedData,
      },
    });
  } catch (err) {
    console.error('[Get Listing Error]', err);
    res.status(500).json({ error: 'Failed to get listing' });
  }
});

// ─── HELPER FUNCTIONS ──────────────────────────────────────────────────────

function normalizePhoneNumber(phone) {
  if (!phone) return null;
  let cleaned = phone.replace(/[^\d+]/g, '');

  if (cleaned.length === 10 && !cleaned.startsWith('+')) {
    cleaned = '+234' + cleaned.substring(1);
  }

  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 10 || digitsOnly.length > 15) {
    return null;
  }

  return cleaned;
}

async function sendSMSOTP(phoneNumber, otp, businessName) {
  try {
    const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

    const message = await twilio.messages.create({
      body: `Your Vukafia business claim code is: ${otp}. Valid for 10 minutes. Reply to confirm.`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phoneNumber,
    });

    console.log(`[SMS Sent] ${phoneNumber}, SID: ${message.sid}`);
    return message;
  } catch (err) {
    console.error('[SMS Error]', err.message);
    throw err;
  }
}

// ─── EXPORT ────────────────────────────────────────────────────────────────
module.exports = router;
