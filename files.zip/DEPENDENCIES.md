# 📦 Package Dependencies for AI Discovery

## Install Command

```bash
npm install bull redis axios twilio
```

## Updated package.json

Add these to your `package.json` dependencies section:

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "axios": "^1.6.0",
    "bcryptjs": "^2.4.3",
    "bull": "^4.11.3",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "express-rate-limit": "^7.1.5",
    "helmet": "^7.1.0",
    "jsonwebtoken": "^9.0.2",
    "knex": "^3.1.0",
    "morgan": "^1.10.0",
    "pg": "^8.10.0",
    "redis": "^4.6.0",
    "sqlite3": "^5.1.7",
    "twilio": "^4.10.0"
  },
  "devDependencies": {
    "eslint": "^8.56.0",
    "jest": "^29.7.0",
    "nodemon": "^3.0.2",
    "supertest": "^6.3.4"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
```

## What Each Package Does

| Package | Purpose | Cost |
|---------|---------|------|
| **bull** | Job queue for weekly crawls | $0 (open-source) |
| **redis** | Cache & job store backend | $0 (self-hosted) or $15/mo (managed) |
| **axios** | HTTP client for API calls | $0 |
| **twilio** | SMS verification | ~$0.01 per SMS |
| **dotenv** | Environment variables | $0 |

## Optional Packages (for specific use cases)

### For Hugging Face LLM
```bash
npm install @huggingface/inference
```

### For local Ollama (free LLM)
```bash
# No npm package needed, uses HTTP API
# Just install Ollama: https://ollama.ai
```

### For Google Maps
```bash
npm install @googlemaps/js-client-library
```

### For Sentry error tracking
```bash
npm install @sentry/node
```

### For Bull UI dashboard (optional)
```bash
npm install @bull-board/express
```

## Verify Installation

After installing, check versions:

```bash
npm list bull redis axios twilio

# Output should show:
# ├── axios@1.6.0
# ├── bull@4.11.3
# ├── redis@4.6.0
# └── twilio@4.10.0
```

## Troubleshooting

### Node version too old
```
Error: Cannot find module 'bull'
→ Requires Node.js 18+
→ Run: node --version
→ Upgrade: nvm install 18
```

### Redis not working
```
Error: connect ECONNREFUSED
→ Start Redis: redis-server
→ Or set REDIS_URL to managed service
```

### npm install fails
```
Error: peer dep warning
→ Safe to ignore for development
→ Production: npm ci --only=production
```

## Production Deployment

### Managed Services (no self-hosting)

**Option 1: Railway** (recommended)
- PostgreSQL add-on ✓
- Redis add-on ✓
- Environment variables ✓
- Just push code → it works

**Option 2: Render**
- PostgreSQL add-on ✓
- Redis add-on ✓
- Auto-deploy from Git ✓

**Option 3: Self-hosted VPS**
- Install Node, Redis, PostgreSQL
- Deploy with Docker Compose
- Manage updates yourself

---

## Lock File

Always commit `package-lock.json` to git:

```bash
git add package.json package-lock.json
git commit -m "Add AI discovery dependencies"
```

This ensures everyone installs exact same versions.

---

## Next Step

Run:
```bash
npm install
npm run dev
```

Then follow the integration guide in `INTEGRATION_GUIDE.md`
