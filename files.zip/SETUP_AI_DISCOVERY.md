# 🚀 Vukafia AI Discovery System — Setup & Deployment Guide

**Quick Overview:** 
- Weeks 1-2: Setup & test local
- Weeks 3-4: Deploy to production (Railway/Render)
- Weeks 5-6: Optimize & scale

---

## 📦 Prerequisites

### Required
- Node.js 18+
- PostgreSQL 13+ (or SQLite for dev)
- Redis 6+ (for job queue)
- Git

### Required API Keys/Services
- **Google Maps API** (Places, Geocoding)
- **Twilio** (SMS verification)
- **Hugging Face** (optional, for LLM inference)
- **Mistral or Ollama** (local LLM)

---

## 1. Install Dependencies

```bash
# Core
npm install express axios knex pg sqlite3 cors helmet morgan express-rate-limit

# Auth & security
npm install jsonwebtoken bcryptjs dotenv

# Job queue (weekly crawls)
npm install bull redis

# LLM & extraction
npm install axios  # For HuggingFace/Ollama API calls
npm install @huggingface/inference  # Optional: direct HF SDK

# SMS
npm install twilio

# Google Maps
npm install @googlemaps/js-client-library

# Optional: Local LLM
# docker pull ollama/ollama
# docker run -d -p 11434:11434 ollama/ollama
# ollama run mistral

# Testing
npm install --save-dev jest supertest
```

### Updated package.json

```json
{
  "name": "vukafia-api",
  "version": "1.0.0",
  "dependencies": {
    "axios": "^1.6.0",
    "bcryptjs": "^2.4.3",
    "bull": "^4.11.3",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "express": "^4.18.2",
    "express-rate-limit": "^7.1.5",
    "helmet": "^7.1.0",
    "jsonwebtoken": "^9.0.2",
    "knex": "^3.1.0",
    "morgan": "^1.10.0",
    "pg": "^8.10.0",
    "redis": "^4.6.0",
    "sqlite3": "^5.1.7",
    "twilio": "^4.10.0"
  },
  "devDependencies": {
    "eslint": "^8.56.0",
    "jest": "^29.7.0",
    "nodemon": "^3.0.2",
    "supertest": "^6.3.4"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}
```

---

## 2. Environment Configuration

### Create `.env` file

```bash
# Server
NODE_ENV=development
PORT=5000
DATABASE_URL=postgresql://user:password@localhost:5432/vukafia
# OR for SQLite: DATABASE_URL=sqlite:./data/vukafia.sqlite

# Redis (for job queue)
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-super-secret-key-min-32-chars-123456789

# Google Maps
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
GOOGLE_PLACES_API_KEY=your_google_places_api_key

# Twilio (SMS)
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=+1234567890  # Your Twilio phone number

# LLM (choose one)
# Option 1: Hugging Face
HF_API_KEY=hf_your_hugging_face_token

# Option 2: Local Ollama (no key needed)
OLLAMA_URL=http://localhost:11434

# WhatsApp
WA_API_TOKEN=your_meta_api_token
WA_PHONE_NUMBER_ID=your_wa_phone_id
WA_VERIFY_TOKEN=random_verify_token

# Allowed origins
ALLOWED_ORIGINS=http://localhost:3000,https://vukafia.com,https://www.vukafia.com

# AI Discovery
AI_DISCOVERY_ENABLED=true
AI_CONFIDENCE_THRESHOLD=0.5  # Min score to add to directory
```

### Create `.env.example`

Copy `.env` → `.env.example` (for version control)

---

## 3. Database Migrations

### Initialize schema

```bash
# Run the migrations SQL
psql -U postgres -d vukafia -f vukafia_schema_migrations.sql

# OR with Knex (create new migration)
npx knex migrate:make add_ai_discovery_tables
# Edit the migration file, paste the schema
npx knex migrate:latest
```

### Verify tables

```bash
# PostgreSQL
psql -U postgres -d vukafia -c "\dt"

# SQLite
sqlite3 data/vukafia.sqlite ".tables"
```

---

## 4. Integrate into server.js

Update your `server.js` to include the AI discovery system:

```javascript
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const db = require('./db');
const listingsRouter = require('./routes/listings');
const businessRouter = require('./routes/business');
const authRouter = require('./routes/auth');
const adminRouter = require('./routes/admin');
const webhookRouter = require('./routes/webhook');
const claimingRouter = require('./routes/claiming');  // NEW

// NEW: Import crawl workers
const { scheduleWeeklyCrawls } = require('./services/crawl_worker');

const app = express();
const PORT = process.env.PORT || 5000;

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '10mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
});

app.use('/api/', apiLimiter);

// ─── ROUTES ───────────────────────────────────────────────────────────────
app.use('/api/listings', listingsRouter);
app.use('/api/business', businessRouter);
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);
app.use('/api/webhook', webhookRouter);
app.use('/api/claiming', claimingRouter);  // NEW: AI discovery claiming

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    ai_discovery: process.env.AI_DISCOVERY_ENABLED === 'true',
  });
});

// ─── STARTUP ───────────────────────────────────────────────────────────────
db.init().then(async () => {
  app.listen(PORT, () => {
    console.log(`\n╔════════════════════════════════════╗`);
    console.log(`║ 🌍 VUKAFIA API v1.0                 ║`);
    console.log(`║ Port: ${PORT}                         ║`);
    console.log(`║ AI Discovery: ${process.env.AI_DISCOVERY_ENABLED === 'true' ? 'ENABLED' : 'DISABLED'}           ║`);
    console.log(`╚════════════════════════════════════╝\n`);

    // NEW: Schedule weekly crawls
    if (process.env.AI_DISCOVERY_ENABLED === 'true') {
      scheduleWeeklyCrawls()
        .then(() => console.log('✅ AI crawl jobs scheduled'))
        .catch(err => console.error('❌ Failed to schedule crawls:', err));
    }
  });
}).catch(err => {
  console.error('❌ DB init failed:', err);
  process.exit(1);
});

module.exports = app;
```

---

## 5. Data Source Configuration

### Seed data sources per country

```bash
# Create a seed script: seeds/seed_data_sources.js
```

```javascript
// seeds/seed_data_sources.js
'use strict';

const db = require('../db');

async function seedDataSources() {
  const dataSources = [
    // Nigeria
    { country_code: 'NG', source_name: 'google_maps', enabled: true },
    { country_code: 'NG', source_name: 'openstreetmap', enabled: true },
    { country_code: 'NG', source_name: 'web_crawl', enabled: false },

    // Ghana
    { country_code: 'GH', source_name: 'google_maps', enabled: true },
    { country_code: 'GH', source_name: 'openstreetmap', enabled: true },
    { country_code: 'GH', source_name: 'web_crawl', enabled: false },

    // Kenya
    { country_code: 'KE', source_name: 'google_maps', enabled: true },
    { country_code: 'KE', source_name: 'openstreetmap', enabled: true },
    { country_code: 'KE', source_name: 'web_crawl', enabled: false },
  ];

  for (const source of dataSources) {
    await db('data_sources').insert(source).onConflict(['country_code', 'source_name']).ignore();
  }

  console.log('✅ Data sources seeded');
}

db.init().then(seedDataSources).catch(console.error);
```

Run it:
```bash
node seeds/seed_data_sources.js
```

---

## 6. Test Locally

### Start services

```bash
# Terminal 1: Redis
redis-server

# Terminal 2: Local LLM (optional)
docker run -p 11434:11434 ollama/ollama
ollama run mistral

# Terminal 3: Node server
npm run dev
```

### Test API endpoints

```bash
# Test health
curl http://localhost:5000/health

# Search for a listing to claim
curl "http://localhost:5000/api/claiming/search?q=electronics&country=NG"

# Initiate claim
curl -X POST http://localhost:5000/api/claiming/initiate \
  -H "Content-Type: application/json" \
  -d '{
    "listing_id": 1,
    "phone_number": "+2348012345678"
  }'

# Verify OTP (use the OTP sent to console in dev)
curl -X POST http://localhost:5000/api/claiming/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "listing_id": 1,
    "claim_token": "abc123...",
    "otp": "123456"
  }'

# Complete claim
curl -X POST http://localhost:5000/api/claiming/complete \
  -H "Content-Type: application/json" \
  -d '{
    "listing_id": 1,
    "claim_token": "abc123...",
    "owner_name": "John Doe",
    "email": "john@example.com",
    "password": "SecurePass123!",
    "phone_number": "+2348012345678"
  }'
```

### Manually trigger a crawl (testing)

```javascript
// In server.js or a test route:
const { crawlQueue } = require('./services/crawl_worker');

// Add a one-time job
crawlQueue.add({
  countryCode: 'NG',
  source: 'google_maps'
});
```

---

## 7. Production Deployment

### Option A: Railway.app

```bash
# 1. Install Railway CLI
npm install -g railway

# 2. Login
railway login

# 3. Create project
railway init

# 4. Add PostgreSQL plugin in dashboard
# 5. Add Redis plugin in dashboard

# 6. Set environment variables in Railway dashboard
# (copy from your .env)

# 7. Deploy
railway up

# 8. Run migrations
railway run npx knex migrate:latest

# 9. Seed data sources
railway run node seeds/seed_data_sources.js
```

### Option B: Render.com

```bash
# 1. Push code to GitHub
git add .
git commit -m "Add AI discovery system"
git push

# 2. Create new Web Service on render.com
# - Connect GitHub repo
# - Set Build Command: npm install
# - Set Start Command: node server.js
# - Add environment variables from .env

# 3. Add PostgreSQL database (managed)
# 4. Add Redis database (managed)

# 5. After deployment, run migrations:
# In dashboard → Services → Your app → Shell
# $ npm run migrate
# $ node seeds/seed_data_sources.js
```

### Option C: Docker (VPS/self-hosted)

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 5000

CMD ["node", "server.js"]
```

```bash
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      DATABASE_URL: postgresql://vukafia:password@postgres:5432/vukafia
      REDIS_URL: redis://redis:6379
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: vukafia
      POSTGRES_USER: vukafia
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

Deploy:
```bash
docker-compose up -d
```

---

## 8. Monitoring & Observability

### Check crawl job status

```javascript
// In a dashboard route or CLI
const { crawlQueue } = require('./services/crawl_worker');

app.get('/api/admin/crawl-status', async (req, res) => {
  const counts = await crawlQueue.getJobCounts();
  const recentJobs = await crawlQueue.getCompleted(0, 10);

  res.json({
    queue_status: counts,
    recent_jobs: recentJobs,
  });
});
```

### Log crawl results

```bash
# View in production:
# Railway: Dashboard → Logs tab
# Render: Services → Service → Logs
# Docker: docker logs <container_id>
```

### Set up error tracking

```bash
# Optional: Sentry for error monitoring
npm install @sentry/node

# Add to server.js:
const Sentry = require('@sentry/node');
Sentry.init({ dsn: process.env.SENTRY_DSN });
app.use(Sentry.Handlers.errorHandler());
```

---

## 9. Cost Breakdown (Month 1)

| Service | Usage | Cost |
|---------|-------|------|
| **Google Maps** | 2,000 API calls | $30 |
| **Twilio SMS** | 500 OTPs @ $0.01 | $5 |
| **Hugging Face** | 5,000 extractions @ $0.0001 | $0.50 |
| **PostgreSQL** | ~50GB (managed DB) | $30 |
| **Redis** | ~10GB (managed cache) | $15 |
| **Railway/Render** | 1 dyno/container | $10–25 |
| **Domain & SSL** | | ~$5 |
| **Total** | | **~$95/month** |

**Cost-saving tips:**
- Use OpenStreetMap (free) instead of Google Maps for 50% of crawls
- Use local Ollama instead of Hugging Face ($0 cost, but needs CPU)
- Cache aggressively (Redis) to reduce API calls

---

## 10. Scaling Checklist

- [ ] Database indexes optimized (`EXPLAIN ANALYZE` queries)
- [ ] Redis connection pooling configured
- [ ] Rate limiting tuned for production
- [ ] Error monitoring (Sentry) active
- [ ] Crawl jobs distributed (if using multiple workers)
- [ ] SMS cost tracking (Twilio alerts)
- [ ] Google Maps quota monitoring
- [ ] Weekly backup schedule
- [ ] CDN for listing images (Cloudinary/S3)

---

## 11. Weekly Maintenance

### Monitor crawl jobs

```bash
# Check crawl_jobs table for failures
SELECT status, COUNT(*) FROM crawl_jobs 
  WHERE created_at > NOW() - INTERVAL 7 DAY
  GROUP BY status;
```

### Check data quality

```bash
# Confidence score distribution
SELECT 
  ROUND(ai_confidence_score, 1) as score,
  COUNT(*) as count,
  COUNT(CASE WHEN verified THEN 1 END) as claimed
FROM listings
WHERE ai_discovered = true
GROUP BY ROUND(ai_confidence_score, 1)
ORDER BY score DESC;
```

### Monitor costs

```bash
# API spend by source
SELECT source_name, api_cost_this_month, records_imported
FROM data_sources
WHERE created_at > NOW() - INTERVAL 30 DAY;
```

---

## 12. Troubleshooting

### Redis connection error
```
Error: connect ECONNREFUSED 127.0.0.1:6379
→ Start Redis: redis-server
→ Or update REDIS_URL in .env
```

### Google Maps API quota
```
Error: OVER_QUERY_LIMIT
→ Wait 24 hours (quota resets daily)
→ Or upgrade Google API billing
```

### SMS not sending
```
Error: SMS send failed
→ Verify Twilio credentials
→ Check TWILIO_PHONE_NUMBER format (E.164)
→ Check account balance
```

### LLM extraction timeout
```
Error: LLM call timeout
→ Check Hugging Face API status
→ Or switch to local Ollama
→ Increase timeout in ai_extractor.js
```

---

## Next Steps

1. **Week 1:** Set up locally, test with 50 businesses
2. **Week 2:** Deploy to staging (Railway), test full flow
3. **Week 3:** Configure production database, run first full crawl
4. **Week 4:** Go live! Monitor for 2 weeks before optimization

---

**Questions?** See README.md for full API documentation.
