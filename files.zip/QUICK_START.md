# ⚡ Quick Start - AI Discovery in 5 Minutes

## TL;DR

```bash
# 1. Install
npm install bull redis axios twilio dotenv

# 2. Copy files
cp -r vukafia-implementation/* your-vukafia-folder/

# 3. Update .env
echo "AI_DISCOVERY_ENABLED=true
REDIS_URL=redis://localhost:6379
HF_API_KEY=your_hf_key_here
TWILIO_ACCOUNT_SID=your_sid
TWILIO_AUTH_TOKEN=your_token
TWILIO_PHONE_NUMBER=+1234567890
GOOGLE_MAPS_API_KEY=your_gmap_key" >> .env

# 4. Run migrations
npx knex migrate:latest

# 5. Seed data sources
node seeds/seed_data_sources.js

# 6. Start (with Redis running)
redis-server &
npm run dev
```

---

## What Gets Added

### New Routes
- `POST /api/claiming/initiate` — Start business claim
- `POST /api/claiming/verify-otp` — Verify OTP
- `POST /api/claiming/complete` — Register user & claim
- `GET /api/claiming/search` — Search for businesses
- `GET /api/claiming/listings/:id` — View listing details

### New Tables (DB)
- `ai_discovered_listings` — Raw AI-extracted data
- `claim_attempts` — Track who's claiming
- `data_sources` — Config per country/source
- `crawl_jobs` — Log of all crawls

### New Services
- `services/ai_extractor.js` — LLM extraction
- `services/crawl_worker.js` — Weekly job queue

### New Routes
- `routes/claiming.js` — Claiming workflow

---

## Confidence Score Breakdown

| Score | Meaning | Action |
|-------|---------|--------|
| **0.0–0.5** | Low quality | Rejected, not added |
| **0.5–0.7** | Medium quality | Added as "pending", sellers correct |
| **0.7–1.0** | High quality | Auto-added to directory |

---

## Weekly Crawl Schedule

Each country gets crawled **once per week** from:
1. **Google Maps** (primary, cost ~$0.015/query)
2. **OpenStreetMap** (free backup)
3. **Web crawl** (disabled by default)

### Cost Per Country/Month

| Source | Calls/Week | Cost/Month |
|--------|-----------|-----------|
| Google Maps | ~200 | ~$12 |
| OpenStreetMap | unlimited | $0 |
| **Total/3 countries** | | **~$36** |

---

## Business Owner Flow (3 Steps)

```
1. Search for their business
   → GET /api/claiming/search?q=name&country=NG
   
2. Initiate claim (sends SMS OTP)
   → POST /api/claiming/initiate
   → SMS: "Your code: 123456"
   
3. Complete claim (creates account)
   → POST /api/claiming/verify-otp
   → POST /api/claiming/complete
   → Account created, seller dashboard unlocked
```

---

## Environment Variables Needed

```bash
# Required for AI Discovery
AI_DISCOVERY_ENABLED=true
REDIS_URL=redis://localhost:6379

# Pick ONE LLM option:
# Option 1: Hugging Face (production)
HF_API_KEY=hf_xxxxxxxxxxx

# Option 2: Local Ollama (free)
OLLAMA_URL=http://localhost:11434

# SMS (Twilio)
TWILIO_ACCOUNT_SID=ACxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxx
TWILIO_PHONE_NUMBER=+1234567890

# Maps (Google)
GOOGLE_MAPS_API_KEY=AIzaxxxxxx
GOOGLE_PLACES_API_KEY=AIzaxxxxxx
```

---

## File Structure Added

```
vukafia/
├── services/
│   ├── ai_extractor.js       ← LLM extraction
│   ├── crawl_worker.js       ← Job queue
│   └── ...
├── routes/
│   ├── claiming.js           ← API endpoints
│   └── ...
├── migrations/
│   └── 001_ai_discovery_schema.sql  ← DB tables
├── seeds/
│   └── seed_data_sources.js  ← Initialize sources
└── docs/
    ├── INTEGRATION_GUIDE.md  ← Full setup
    ├── SETUP_AI_DISCOVERY.md ← Deployment
    └── QUICK_START.md        ← This file
```

---

## Testing Endpoints

### Search for businesses
```bash
curl "http://localhost:5000/api/claiming/search?q=electronics&country=NG"
```

### Initiate claim
```bash
curl -X POST http://localhost:5000/api/claiming/initiate \
  -H "Content-Type: application/json" \
  -d '{"listing_id":1,"phone_number":"+2348012345678"}'
```

### Verify OTP (use from SMS)
```bash
curl -X POST http://localhost:5000/api/claiming/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"listing_id":1,"claim_token":"abc123","otp":"123456"}'
```

### Complete claim
```bash
curl -X POST http://localhost:5000/api/claiming/complete \
  -H "Content-Type: application/json" \
  -d '{
    "listing_id":1,
    "claim_token":"abc123",
    "owner_name":"John Doe",
    "email":"john@email.com",
    "password":"StrongPass123!",
    "phone_number":"+2348012345678"
  }'
```

---

## Common Issues & Fixes

| Issue | Fix |
|-------|-----|
| `ECONNREFUSED 6379` | Start Redis: `redis-server` |
| `401 Unauthorized` | Check Google Maps API key |
| `SMS not sending` | Verify Twilio credentials in .env |
| `LLM timeout` | Use local Ollama or check HF API status |
| `OVER_QUERY_LIMIT` | Google quota resets daily; wait or upgrade |

---

## Next Steps

1. **Local Testing** (today)
   - Run migrations
   - Seed data sources
   - Test claiming flow

2. **Production Deploy** (this week)
   - Railway or Render
   - Set environment variables
   - Run migrations on prod DB

3. **Monitor & Optimize** (ongoing)
   - Watch crawl_jobs for errors
   - Track API costs
   - Tune confidence thresholds

---

## Need Help?

- **Setup issues?** → See `INTEGRATION_GUIDE.md`
- **Deployment?** → See `SETUP_AI_DISCOVERY.md`
- **API questions?** → Check inline comments in route files

---

**You're all set! 🚀**
