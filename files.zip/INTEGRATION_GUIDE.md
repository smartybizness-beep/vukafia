# 🚀 Vukafia AI Discovery - Integration Guide

This guide shows how to integrate the AI discovery system into your existing Vukafia backend.

---

## Step 1: Copy Files to Your Project

```bash
# From vukafia-implementation folder to your project:
cp -r services/* your-project/services/
cp -r routes/* your-project/routes/
cp -r migrations/* your-project/migrations/
cp -r seeds/* your-project/seeds/
```

### File Structure After Copying

```
your-project/
├── services/
│   ├── ai_extractor.js          (NEW)
│   ├── crawl_worker.js          (NEW)
│   └── ... (existing services)
├── routes/
│   ├── claiming.js              (NEW)
│   └── ... (existing routes)
├── migrations/
│   └── 001_ai_discovery_schema.sql  (NEW)
├── seeds/
│   └── seed_data_sources.js     (NEW)
└── server.js                    (MODIFY)
```

---

## Step 2: Install New Dependencies

```bash
npm install bull redis axios twilio dotenv
```

### Optional (for local LLM):
```bash
# For Hugging Face API (recommended for production):
npm install @huggingface/inference

# OR for local Ollama (free, but needs Docker):
docker pull ollama/ollama
docker run -d -p 11434:11434 ollama/ollama
ollama run mistral
```

---

## Step 3: Update Your `.env` File

Add these variables to your `.env`:

```bash
# ──── AI DISCOVERY ────────────────────────────────────────────────
AI_DISCOVERY_ENABLED=true

# ──── LLM (Choose one option) ──────────────────────────────────────
# Option 1: Hugging Face (Recommended for production)
HF_API_KEY=hf_your_hugging_face_api_key_here
OLLAMA_URL=disabled

# Option 2: Local Ollama (Free, runs locally)
# HF_API_KEY=disabled
# OLLAMA_URL=http://localhost:11434

# ──── TWILIO (For SMS OTP) ─────────────────────────────────────────
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=+1234567890

# ──── GOOGLE MAPS API ─────────────────────────────────────────────
GOOGLE_MAPS_API_KEY=your_google_maps_api_key
GOOGLE_PLACES_API_KEY=your_google_places_api_key

# ──── REDIS (For job queue) ───────────────────────────────────────
REDIS_URL=redis://localhost:6379

# ──── AI SETTINGS ─────────────────────────────────────────────────
AI_CONFIDENCE_THRESHOLD=0.5  # Min score to add to directory
AI_CRAWL_FREQUENCY=weekly    # 'weekly' or 'daily'
```

---

## Step 4: Update Database Schema

### Option A: Run Migration File (PostgreSQL)

```bash
# Direct SQL
psql -U postgres -d vukafia -f migrations/001_ai_discovery_schema.sql

# OR with Knex
npx knex migrate:make add_ai_discovery
# Copy contents of 001_ai_discovery_schema.sql into the migration file
npx knex migrate:latest
```

### Option B: For SQLite

The migration file uses standard SQL compatible with SQLite. Just run:

```bash
sqlite3 data/vukafia.sqlite < migrations/001_ai_discovery_schema.sql
```

---

## Step 5: Update server.js

Replace your current `server.js` with this updated version:

```javascript
/**
 * server.js
 * Updated with AI Discovery integration
 */

'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const db = require('./db');

// ─── ROUTE IMPORTS ────────────────────────────────────────────────────────
const listingsRouter = require('./routes/listings');
const businessRouter = require('./routes/business');
const authRouter = require('./routes/auth');
const adminRouter = require('./routes/admin');
const webhookRouter = require('./routes/webhook');
const claimingRouter = require('./routes/claiming');  // ⭐ NEW

// ─── CRAWL WORKER IMPORTS ─────────────────────────────────────────────────
const { scheduleWeeklyCrawls } = require('./services/crawl_worker');  // ⭐ NEW

// ─── APP SETUP ─────────────────────────────────────────────────────────────
const app = express();
const PORT = process.env.PORT || 5000;
const isDev = process.env.NODE_ENV !== 'production';

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(morgan(isDev ? 'dev' : 'combined'));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 200,
  message: 'Too many requests, please try again later',
});
app.use('/api/', apiLimiter);

// ─── ROUTES ───────────────────────────────────────────────────────────────
app.use('/api/listings', listingsRouter);
app.use('/api/business', businessRouter);
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);
app.use('/api/webhook', webhookRouter);
app.use('/api/claiming', claimingRouter);  // ⭐ NEW: AI discovery claiming

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    ai_discovery: process.env.AI_DISCOVERY_ENABLED === 'true',
    node_env: process.env.NODE_ENV,
  });
});

// ─── ADMIN: CRAWL STATUS ──────────────────────────────────────────────────
app.get('/api/admin/crawl-status', async (req, res) => {
  try {
    const crawlJobs = await db('crawl_jobs')
      .orderBy('created_at', 'desc')
      .limit(20);

    const dataSources = await db('data_sources')
      .where('enabled', true)
      .select('country_code', 'source_name', 'last_crawl_at', 'api_cost_this_month');

    res.json({
      recent_crawls: crawlJobs,
      data_sources: dataSources,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── ERROR HANDLER ────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: isDev ? err.message : 'Internal server error',
  });
});

// ─── STARTUP ──────────────────────────────────────────────────────────────
async function start() {
  try {
    // Initialize database
    await db.init();
    console.log('✅ Database initialized');

    // Start server
    const server = app.listen(PORT, () => {
      console.log(`\n╔════════════════════════════════════╗`);
      console.log(`║ 🌍 VUKAFIA API                      ║`);
      console.log(`║ Port: ${PORT}                              ║`);
      console.log(`║ Environment: ${process.env.NODE_ENV || 'development'}      ║`);
      console.log(`║ AI Discovery: ${process.env.AI_DISCOVERY_ENABLED === 'true' ? '✓ ENABLED' : '✗ DISABLED'}         ║`);
      console.log(`╚════════════════════════════════════╝\n`);
    });

    // ⭐ SCHEDULE WEEKLY CRAWLS (if enabled)
    if (process.env.AI_DISCOVERY_ENABLED === 'true') {
      try {
        await scheduleWeeklyCrawls();
        console.log('✅ Weekly crawl jobs scheduled\n');
      } catch (err) {
        console.error('⚠️  Failed to schedule crawls:', err.message);
        console.error('   AI discovery is enabled but crawl scheduling failed.');
        console.error('   Check your Redis connection and try again.\n');
      }
    }

  } catch (err) {
    console.error('❌ Startup failed:', err.message);
    process.exit(1);
  }
}

// Start server
start();

module.exports = app;
```

---

## Step 6: Initialize Data Sources

```bash
# Run the seed script
node seeds/seed_data_sources.js

# Expected output:
# ✓ NG/google_maps (created)
# ✓ NG/openstreetmap (created)
# ✓ GH/google_maps (created)
# ... etc

# ✅ Data sources seeded successfully!
```

---

## Step 7: Test Locally

### Start all services (in separate terminals):

```bash
# Terminal 1: Redis
redis-server

# Terminal 2: Node server
npm run dev

# Terminal 3 (optional): Local LLM
docker run -p 11434:11434 ollama/ollama
```

### Test the API:

```bash
# 1. Health check
curl http://localhost:5000/health

# 2. Search for listings to claim
curl "http://localhost:5000/api/claiming/search?q=electronics&country=NG"

# 3. Initiate claim
curl -X POST http://localhost:5000/api/claiming/initiate \
  -H "Content-Type: application/json" \
  -d '{
    "listing_id": 1,
    "phone_number": "+2348012345678"
  }'

# 4. Check crawl status
curl http://localhost:5000/api/admin/crawl-status
```

---

## Step 8: First Crawl (Manual Testing)

```bash
# Create a temporary script: test_crawl.js
```

```javascript
// test_crawl.js
const { crawlQueue } = require('./services/crawl_worker');

async function runCrawl() {
  const job = await crawlQueue.add({
    countryCode: 'NG',
    source: 'google_maps',
  });

  console.log(`Job added: ${job.id}`);
  console.log('Check status with: npx bull-board');
}

runCrawl();
```

```bash
node test_crawl.js
```

---

## Step 9: Deploy to Production

### Railway.app

```bash
railway up
railway run npx knex migrate:latest
railway run node seeds/seed_data_sources.js
```

### Render.com

1. Push code to GitHub
2. Connect repo in Render dashboard
3. Add PostgreSQL & Redis add-ons
4. Set environment variables
5. After deploy, run:
   ```bash
   # In dashboard shell:
   npm run migrate
   node seeds/seed_data_sources.js
   ```

---

## Troubleshooting

### Redis Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:6379
→ Start Redis: redis-server
→ Or set REDIS_URL=redis://your-prod-url
```

### Google Maps API Error
```
Error: OVER_QUERY_LIMIT
→ Quota resets daily at 12 AM PST
→ Or upgrade your billing plan
```

### LLM Timeout
```
Error: LLM call timeout
→ Check Hugging Face API status
→ Or switch to local Ollama
```

### Database Migration Error
```
Error: relation "ai_discovered_listings" already exists
→ Good news! Migration already ran. Proceed.
```

---

## What's Next?

1. ✅ Files copied and integrated
2. ✅ Database migrations applied
3. ✅ Data sources seeded
4. ✅ API tested locally
5. 🔄 Deploy to production
6. 🔄 Monitor crawl jobs
7. 🔄 Watch business owners claim listings

---

## Cost Tracking

Monitor monthly API spend:

```bash
# Check current costs
psql -U postgres -d vukafia -c "
  SELECT country_code, source_name, api_calls_this_month, api_cost_this_month
  FROM data_sources
  ORDER BY api_cost_this_month DESC;
"
```

---

## Support

- **Issues?** Check `/docs/SETUP_AI_DISCOVERY.md` for full setup guide
- **Questions?** See the inline comments in each service file
- **Bugs?** Check `/routes/claiming.js` for error messages in your logs

---

**Happy discovering! 🎉**
