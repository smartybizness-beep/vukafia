/**
 * seeds/seed_data_sources.js
 * 
 * Initialize data sources for Nigeria, Ghana, Kenya
 * 
 * Run: node seeds/seed_data_sources.js
 */

'use strict';

const db = require('../db');

async function seedDataSources() {
  try {
    console.log('[Seed] Starting data sources initialization...');

    const dataSources = [
      // ─── NIGERIA ───────────────────────────────────────────────────────────
      {
        country_code: 'NG',
        source_name: 'google_maps',
        enabled: true,
        config: JSON.stringify({
          priority_categories: ['electronics', 'retail', 'services', 'legal services', 'health'],
          regions: ['Lagos', 'Abuja', 'Port Harcourt', 'Ibadan', 'Kano'],
        }),
      },
      {
        country_code: 'NG',
        source_name: 'openstreetmap',
        enabled: true,
        config: JSON.stringify({
          priority: 'secondary',
          cost: 'free',
        }),
      },
      {
        country_code: 'NG',
        source_name: 'web_crawl',
        enabled: false,
        config: JSON.stringify({
          priority: 'low',
          status: 'future',
        }),
      },

      // ─── GHANA ──────────────────────────────────────────────────────────────
      {
        country_code: 'GH',
        source_name: 'google_maps',
        enabled: true,
        config: JSON.stringify({
          priority_categories: ['electronics', 'retail', 'services', 'legal services', 'health'],
          regions: ['Accra', 'Kumasi', 'Sekondi-Takoradi', 'Cape Coast'],
        }),
      },
      {
        country_code: 'GH',
        source_name: 'openstreetmap',
        enabled: true,
        config: JSON.stringify({
          priority: 'secondary',
          cost: 'free',
        }),
      },
      {
        country_code: 'GH',
        source_name: 'web_crawl',
        enabled: false,
        config: JSON.stringify({
          priority: 'low',
          status: 'future',
        }),
      },

      // ─── KENYA ──────────────────────────────────────────────────────────────
      {
        country_code: 'KE',
        source_name: 'google_maps',
        enabled: true,
        config: JSON.stringify({
          priority_categories: ['electronics', 'retail', 'services', 'legal services', 'health'],
          regions: ['Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Kericho'],
        }),
      },
      {
        country_code: 'KE',
        source_name: 'openstreetmap',
        enabled: true,
        config: JSON.stringify({
          priority: 'secondary',
          cost: 'free',
        }),
      },
      {
        country_code: 'KE',
        source_name: 'web_crawl',
        enabled: false,
        config: JSON.stringify({
          priority: 'low',
          status: 'future',
        }),
      },
    ];

    // Insert or ignore if already exists
    for (const source of dataSources) {
      try {
        const existing = await db('data_sources')
          .where({ country_code: source.country_code, source_name: source.source_name })
          .first();

        if (existing) {
          console.log(`  ✓ ${source.country_code}/${source.source_name} (already exists)`);
        } else {
          await db('data_sources').insert(source);
          console.log(`  ✓ ${source.country_code}/${source.source_name} (created)`);
        }
      } catch (err) {
        console.error(`  ✗ ${source.country_code}/${source.source_name}: ${err.message}`);
      }
    }

    console.log('\n✅ Data sources seeded successfully!\n');
    console.log('Next steps:');
    console.log('  1. Set GOOGLE_MAPS_API_KEY in .env');
    console.log('  2. Start crawling: node scripts/trigger_crawl.js');
    console.log('  3. Check results: SELECT * FROM ai_discovered_listings LIMIT 10;');

  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  }
}

// Run if executed directly
if (require.main === module) {
  db.init()
    .then(seedDataSources)
    .then(() => process.exit(0))
    .catch(err => {
      console.error(err);
      process.exit(1);
    });
}

module.exports = { seedDataSources };
